RecommenderBase
===============

.. autoclass:: implicit.recommender_base.RecommenderBase
   :members:
   :undoc-members:
