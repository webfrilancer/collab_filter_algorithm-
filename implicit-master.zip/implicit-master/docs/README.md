Compiled [documentation can be found on readthedocs](http://implicit.readthedocs.io/).

