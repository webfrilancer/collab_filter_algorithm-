BayesianPersonalizedRanking
===========================

.. autoclass:: implicit.bpr.BayesianPersonalizedRanking
   :members:
   :inherited-members:
