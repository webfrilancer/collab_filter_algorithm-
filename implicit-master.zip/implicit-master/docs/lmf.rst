LogisticMatrixFactorization
===========================

.. autoclass:: implicit.lmf.LogisticMatrixFactorization
   :members:
   :inherited-members:
